// import React from 'react'


// const UserStats = (props) => {
//     console.log("map list " + props)
//     return (
// <div className="card">
//   <div className="container">
//     <h4><b>John Doe</b></h4> 
//     <p>Engineer</p> 
//   </div>
// </div>
//     )
// }

// export default UserStats